package com.example.coinnest;

public class LogoutActivity {
}
